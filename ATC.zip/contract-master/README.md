# HEX

## Contracts
Please see the [contracts/](contracts) directory.

## Develop
Contracts are written in Solidity. Library contracts sourced from OpenZeppelin.org.

### Installation
```bash
npm install
```

### Compilation
```bash
npm run build
```
